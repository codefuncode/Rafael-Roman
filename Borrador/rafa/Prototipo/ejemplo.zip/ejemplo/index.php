<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <link href="https://www.w3schools.com/w3css/4/w3.css" rel="stylesheet"/>
    <title>
      Document
    </title>
  </head>
  <body>
    <form class="w3-container ">
      <div class="w3-container w3-padding w3-margin">
        <div class="w3-row-padding">
          <div class="w3-third">
            <input checked="" class="w3-radio" name="gender" type="radio" value="male"/>
            <label>
              Male
            </label>
          </div>
          <div class="w3-third">
            <input checked="" class="w3-radio" name="gender" type="radio" value="male"/>
            <label>
              Male
            </label>
          </div>
        </div>
      </div>
      <div class="w3-row-padding">
        <div class="w3-third">
          <input class="w3-input w3-border" id="inpin_stock" placeholder="One" type="text"/>
        </div>
        <div class="w3-third">
          <input class="w3-input w3-border" placeholder="Two" type="text"/>
        </div>
      </div>
      <div class="w3-container w3-padding w3-margin">
        <input class="w3-btn w3-black" type="button" value="Input Button"/>
        <input class="w3-btn w3-black" type="button" value="Input Button"/>
        <input class="w3-btn w3-black" type="button" value="Input Button"/>
        <input class="w3-btn w3-black" type="button" value="Input Button"/>
      </div>
      <div class="w3-container w3-padding">
        <table class="w3-table">
          <tr>
            <th>
              First Name
            </th>
            <th>
              Last Name
            </th>
            <th>
              Points
            </th>
          </tr>
          <tr>
            <td>
              Jill
            </td>
            <td>
              Smith
            </td>
            <td>
              50
            </td>
          </tr>
        </table>
      </div>
    </form>
    <script src="js.js" type="text/javascript">
    </script>
  </body>
</html>
