CREATE TABLE prueba(
    idprueba INT NOT NULL AUTO_INCREMENT,
    stocknumber VARCHAR(10) NULL,
    binlocation VARCHAR(10) NULL,
    binlocation VARCHAR(10) NULL,
    PRIMARY KEY (idprueba)
);